import type { CwaConfig } from '@cwa/types'

export default {
  name: 'form-input-field',
  version: '1.0.0',
  customizable: {

  }
} as CwaConfig